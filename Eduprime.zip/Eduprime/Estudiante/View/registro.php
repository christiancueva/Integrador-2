<!DOCTYPE html>
<html>
<head>
    <title>EDUPRIME - Registro</title>
    <style>
        body {
            background-color: #121c3f;
            color: white;
            font-family: Arial, sans-serif;
        }
        
        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        
        .card {
            background-color: #1d2d5c;
            width: 400px;
            padding: 40px;
            border-radius: 8px;
        }
        
        .logo {
            text-align: left;
            margin-bottom: 20px;
        }
        
        .logo img {
            width: 150px;
        }
        
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-top: 10px;
        }
        
        input[type="email"],
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: none;
            background-color: #eee;
            color: #333;
            border-radius: 4px;
        }
        
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            background-color: #fff;
            color: #1d2d5c;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .register-link {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="logo">
                <img src="logo.png" alt="EDUPRIME Logo">
            </div>
            <h1>EDUPRIME - Registro</h1>
            <form action="registro.php" method="POST">
                <label for="correo">Correo Electrónico:</label>
                <input type="email" name="correo" required>

                <label for="nombre">Nombres:</label>
                <input type="text" name="nombre" required>

                <label for="apellido">Apellidos:</label>
                <input type="text" name="apellido" required>

                <label for="telefono">Teléfono/Celular:</label>
                <input type="text" name="telefono" required>

                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" required>

                <input type="submit" value="Registrarse">
            </form>
            <div class="register-link">
                <p>¿No tienes una cuenta? <a href="inicio_sesion.php">Regístrate</a></p>
            </div>
        </div>
    </div>
</body>
</html>